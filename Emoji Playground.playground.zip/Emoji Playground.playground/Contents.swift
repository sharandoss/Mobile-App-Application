let 🌸 = 1
let 🌸🌸 = 2

func ＋(_ 🐶: Int, _ 🐮: Int) -> Int {
    🐶 + 🐮
}

let 🌸🌸🌸 = ＋(🌸🌸, 🌸)

print(🌸🌸🌸)
